var express = require('express');
var app = express();


var mysql = require('mysql');

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

var dbConn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "videoigre"
});
    
dbConn.connect(); 

app.post("/igre", function(request, response){
    var Naslov = request.body.Naslov;
    var DatumObjavljivanja = request.body.DatumObjavljivanja;
    var Cijena = request.body.Cijena;

    dbConn.query('INSERT INTO igre VALUES (NULL,?,?,?)', [Naslov, DatumObjavljivanja, Cijena], function(error, results, fields) {
        if (error) throw error;
        return response.send({ error: false, data: results, message:'Uspješno dodana igra: '+Naslov });
    })
})

app.put("/igre/:RedniBroj", function(request, response){
    var RedniBroj = request.params.RedniBroj;
    var Naslov = request.body.Naslov;
    var DatumObjavljivanja = request.body.DatumObjavljivanja;
    var Cijena = request.body.Cijena;

    dbConn.query('UPDATE igre SET Naslov=?, DatumObjavljivanja=?, Cijena=? WHERE RedniBroj=?', [Naslov, DatumObjavljivanja, Cijena, RedniBroj], function(error, results, fields) {
        if (error) throw error;
        return response.send({ error: false, data: results, message:'Uspješno ažurirana igra: '+ Naslov});
    })
})

app.delete("/igre/:RedniBroj", function(request, response){
    var RedniBroj = request.params.RedniBroj;

    dbConn.query('DELETE FROM igre where RedniBroj=?', RedniBroj, function(error, results, fields) {
        if (error) throw error;
        return response.send({ error: false, data: results[0], message:'Uspješno izbrisana igra: ='+RedniBroj });
    })
})

app.get("/igre", function(request, response){
    //return response.send({message:"READ korisnik"});
    dbConn.query('SELECT * FROM igre', function (error, results, fields) {
        if (error) throw error;
        return response.send({ error: false, data: results, message: 'Dohvaća sve igre.' });
    })
})

app.get("/igre/:RedniBroj", function(request, response){
    //var id = request.params.id;
    //return response.send({message: "READ korisnik "+id});

    let RedniBroj = request.params.RedniBroj;
    if (!RedniBroj) {
    return response.status(400).send({ error: true, message: 'Sifra: ' });
    }
    dbConn.query('SELECT * FROM igre where RedniBroj=?', RedniBroj, function(error, results, fields) {
    if (error) throw error;
    return response.send({ error: false, data: results[0], message:'Dohvaćena igra' });
});

})
// set port
app.listen(3000, function () {
    console.log('Node app is running on port 3000');
})